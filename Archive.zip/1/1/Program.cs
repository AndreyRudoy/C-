﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1
{
    class Program
    {
        static void Main()
        {
            string s = null;
            double u = 0;
            double r = 0;

            Console.Write("U: ");
            do
            {
                s = Console.ReadLine();
                if (double.TryParse(s, out u))
                    s = null;
                else
                    Console.WriteLine("Ошибка");
            } while (s != null);

            Console.Write("R: ");
            do
            {
                s = Console.ReadLine();
                if (double.TryParse(s, out r))
                    s = null;
                else
                    Console.WriteLine("Ошибка");
            } while (s != null);

            double om = 0;
            om = u / r;
            Console.WriteLine("I: {0}", om);
            Console.ReadKey();
        }
    }
}
