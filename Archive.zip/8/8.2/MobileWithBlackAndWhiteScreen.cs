﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_8._2
{
    class MobileWithBlackAndWhiteScreen : ButtonTelephone
    {
        public MobileWithBlackAndWhiteScreen(string name) : base(name)
        {

        }
    }
}
