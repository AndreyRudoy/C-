﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_8._2
{
    class ButtonTelephone : DiskPhone
    {
        public ButtonTelephone(string name) : base(name)
        {

        }
    }
}
